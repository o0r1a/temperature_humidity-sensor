# temperature_humidity_sensors
Sensor Humidity and temperatur using nodemcu DHT11

Requirement : 

-NodeMcu With ESP 8266
- DHT11 Sensor Temperature
- Thingspeak account 


Board Scheme : 

- Signal ->  3v nodemcu
- VCC ->  1D 
- GND ->  GND

